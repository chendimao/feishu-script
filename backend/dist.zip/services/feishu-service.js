"use strict";
/**
 * 飞书多维表格 API 服务
 * 提供读取、写入、字段操作等功能
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTableFields = getTableFields;
exports.getTableRecords = getTableRecords;
exports.updateTableRecords = updateTableRecords;
const feishu_auth_1 = require("../utils/feishu-auth");
const FEISHU_API_BASE = 'https://open.feishu.cn/open-api/bitable/v1';
/**
 * 飞书 API 错误处理
 */
function handleFeishuError(error, context) {
    console.error(`飞书 API 错误 [${context}]:`, error);
    throw {
        success: false,
        error: error.message || '飞书 API 调用失败',
        context
    };
}
/**
 * 获取表格的字段列表
 */
async function getTableFields(appToken, tableId) {
    try {
        const headers = await (0, feishu_auth_1.createFeishuHeaders)();
        const response = await fetch(`${FEISHU_API_BASE}/apps/${appToken}/tables/${tableId}/fields`, {
            headers
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        if (data.code !== 0) {
            throw new Error(data.msg);
        }
        // 转换字段类型编号为名称
        const typeMap = {
            1: 'text',
            2: 'number',
            3: 'singleSelect',
            4: 'multiSelect',
            5: 'date',
            7: 'checkbox',
            11: 'url',
            13: 'phone',
            14: 'email'
        };
        return data.data.items.map(field => ({
            fieldId: field.field_id,
            fieldName: field.field_name,
            fieldType: typeMap[field.type] || 'unknown'
        }));
    }
    catch (error) {
        handleFeishuError(error, '获取字段列表');
    }
}
/**
 * 获取表格记录列表
 */
async function getTableRecords(appToken, tableId, options) {
    try {
        const headers = await (0, feishu_auth_1.createFeishuHeaders)();
        const params = new URLSearchParams();
        if (options?.fieldIds?.length) {
            params.append('field_ids', options.fieldIds.join(','));
        }
        if (options?.pageSize) {
            params.append('page_size', String(options.pageSize));
        }
        if (options?.pageToken) {
            params.append('page_token', options.pageToken);
        }
        const url = `${FEISHU_API_BASE}/apps/${appToken}/tables/${tableId}/records?${params.toString()}`;
        const response = await fetch(url, { headers });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        if (data.code !== 0) {
            throw new Error(data.msg);
        }
        return {
            records: data.data.items.map(item => ({
                recordId: item.record_id,
                ...item.fields
            })),
            pageToken: data.data.page_token,
            hasMore: data.data.has_more,
            total: data.data.total
        };
    }
    catch (error) {
        handleFeishuError(error, '获取记录列表');
    }
}
/**
 * 批量更新记录
 */
async function updateTableRecords(appToken, tableId, records) {
    try {
        const headers = await (0, feishu_auth_1.createFeishuHeaders)();
        const response = await fetch(`${FEISHU_API_BASE}/apps/${appToken}/tables/${tableId}/records/batch_update`, {
            method: 'POST',
            headers,
            body: JSON.stringify({
                records: records.map(record => ({
                    record_id: record.recordId,
                    fields: record.fields
                }))
            })
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        if (data.code !== 0) {
            throw new Error(data.msg);
        }
        return {
            success: true,
            updatedCount: data.data.records.length
        };
    }
    catch (error) {
        handleFeishuError(error, '批量更新记录');
    }
}
//# sourceMappingURL=feishu-service.js.map