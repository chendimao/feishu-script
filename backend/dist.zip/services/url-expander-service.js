"use strict";
/**
 * URL 解析服务
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.expandUrls = expandUrls;
const url_expander_1 = require("../utils/url-expander");
/**
 * 批量解析 URL
 */
async function expandUrls(urls) {
    const results = await (0, url_expander_1.expandUrlsInBatch)(urls);
    const successCount = results.filter(r => r.success).length;
    return {
        success: true,
        total: urls.length,
        successCount,
        failedCount: results.length - successCount,
        results
    };
}
//# sourceMappingURL=url-expander-service.js.map