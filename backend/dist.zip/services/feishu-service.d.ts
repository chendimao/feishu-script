/**
 * 飞书多维表格 API 服务
 * 提供读取、写入、字段操作等功能
 */
export interface FeishuField {
    fieldId: string;
    fieldName: string;
    fieldType: string;
}
export interface FeishuRecord {
    recordId: string;
    [key: string]: any;
}
/**
 * 获取表格的字段列表
 */
export declare function getTableFields(appToken: string, tableId: string): Promise<FeishuField[]>;
/**
 * 获取表格记录列表
 */
export declare function getTableRecords(appToken: string, tableId: string, options?: {
    fieldIds?: string[];
    pageSize?: number;
    pageToken?: string;
}): Promise<{
    records: FeishuRecord[];
    pageToken: string;
    hasMore: boolean;
    total: number;
}>;
/**
 * 批量更新记录
 */
export declare function updateTableRecords(appToken: string, tableId: string, records: Array<{
    recordId: string;
    fields: Record<string, any>;
}>): Promise<{
    success: boolean;
    updatedCount: number;
}>;
//# sourceMappingURL=feishu-service.d.ts.map