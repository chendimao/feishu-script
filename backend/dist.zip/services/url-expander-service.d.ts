/**
 * URL 解析服务
 */
import { ExpandResult } from '../utils/url-expander';
export { ExpandResult };
/**
 * 批量解析 URL
 */
export declare function expandUrls(urls: string[]): Promise<{
    success: boolean;
    total: number;
    successCount: number;
    failedCount: number;
    results: ExpandResult[];
}>;
//# sourceMappingURL=url-expander-service.d.ts.map