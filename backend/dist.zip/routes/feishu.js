"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const feishuService = __importStar(require("../services/feishu-service"));
const router = (0, express_1.Router)();
/**
 * GET /api/feishu/fields
 * 获取表格字段列表
 */
router.get('/fields', async (req, res, next) => {
    try {
        const { app_token, table_id } = req.query;
        if (!app_token || !table_id) {
            res.status(400).json({
                success: false,
                error: '缺少必要参数: app_token 和 table_id',
                errorType: 'INVALID_PARAM'
            });
            return;
        }
        const fields = await feishuService.getTableFields(String(app_token), String(table_id));
        res.json({
            success: true,
            data: fields
        });
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/feishu/records
 * 获取表格记录列表
 */
router.post('/records', async (req, res, next) => {
    try {
        const { appToken, tableId, fieldIds, pageSize, pageToken } = req.body;
        if (!appToken || !tableId) {
            res.status(400).json({
                success: false,
                error: '缺少必要参数: appToken 和 tableId',
                errorType: 'INVALID_PARAM'
            });
            return;
        }
        const result = await feishuService.getTableRecords(appToken, tableId, {
            fieldIds,
            pageSize,
            pageToken
        });
        res.json({
            success: true,
            data: result
        });
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/feishu/records/update
 * 批量更新记录
 */
router.post('/records/update', async (req, res, next) => {
    try {
        const { appToken, tableId, records } = req.body;
        if (!appToken || !tableId || !records || !Array.isArray(records)) {
            res.status(400).json({
                success: false,
                error: '缺少必要参数或参数格式错误',
                errorType: 'INVALID_PARAM'
            });
            return;
        }
        const result = await feishuService.updateTableRecords(appToken, tableId, records);
        res.json({
            success: true,
            data: result
        });
    }
    catch (error) {
        next(error);
    }
});
exports.default = router;
//# sourceMappingURL=feishu.js.map