"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const health_1 = __importDefault(require("./health"));
const feishu_1 = __importDefault(require("./feishu"));
const url_expand_1 = __importDefault(require("./url-expand"));
const router = (0, express_1.Router)();
// 健康检查
router.use('/health', health_1.default);
// 飞书 API
router.use('/feishu', feishu_1.default);
// URL 解析
router.use('/url-expand', url_expand_1.default);
exports.default = router;
//# sourceMappingURL=index.js.map