"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorHandler = void 0;
const errorHandler = (err, req, res, next) => {
    console.error(`[Error] ${err.message}`, {
        url: req.url,
        method: req.method,
        stack: err.stack
    });
    const statusCode = err.statusCode || 500;
    const errorType = err.errorType || 'INTERNAL_ERROR';
    res.status(statusCode).json({
        success: false,
        error: err.message || 'Internal Server Error',
        errorType,
        timestamp: new Date().toISOString()
    });
};
exports.errorHandler = errorHandler;
//# sourceMappingURL=error-handler.js.map