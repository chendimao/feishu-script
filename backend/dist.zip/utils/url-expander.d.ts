/**
 * URL 解析器服务
 * 封装 url-expander-server.js 的核心逻辑
 */
export interface ExpandResult {
    success: boolean;
    originalUrl: string;
    expandedUrl?: string;
    error?: string;
    errorType?: string;
}
/**
 * 解析单个 URL
 */
export declare function expandUrl(shortUrl: string): Promise<ExpandResult>;
/**
 * 批量解析 URL
 */
export declare function expandUrlsInBatch(urls: string[]): Promise<ExpandResult[]>;
/**
 * 从文本中提取 URL
 */
export declare function extractUrls(text: string): string[];
//# sourceMappingURL=url-expander.d.ts.map