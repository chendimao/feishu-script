/**
 * 飞书 API 认证工具
 * 处理 tenant_access_token 的获取和缓存
 */
/**
 * 获取 tenant_access_token
 * 飞书 token 有效期为 2 小时,需要缓存管理
 */
export declare function getTenantAccessToken(): Promise<string>;
/**
 * 清除 token 缓存
 * 用于强制重新获取 token
 */
export declare function clearTokenCache(): void;
/**
 * 创建飞书 API 请求头
 */
export declare function createFeishuHeaders(): Promise<Record<string, string>>;
//# sourceMappingURL=feishu-auth.d.ts.map