export declare const config: {
    port: number;
    nodeEnv: string;
    feishu: {
        appId: string;
        appSecret: string;
    };
    corsOrigin: string;
    urlExpander: {
        maxConcurrent: number;
        timeout: number;
    };
};
export declare function validateConfig(): void;
//# sourceMappingURL=index.d.ts.map