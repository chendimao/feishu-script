# 🚀 部署说明

## 📦 构建产物说明
此目录包含完整的生产部署文件：

### 核心文件
- `server/index.mjs` - 服务器入口文件
- `public/` - 静态资源文件

### 配置文件
- `.env` - 环境变量配置
- `package.json` - 依赖信息
- `ecosystem.config.cjs` - PM2配置

### 部署步骤

#### Windows系统:
1. 双击运行 `start-windows.bat` 启动脚本
2. 或者使用命令行:
   - 直接启动: `npm start`
   - PM2启动: `npm run start:pm2`

#### Linux/Mac系统:
1. 安装依赖: `npm install --production`
2. 配置环境变量: `nano .env`
3. 启动服务: `pm2 start ecosystem.config.cjs`

### 访问地址
- 本地: http://localhost:3030
- 服务器: http://服务器IP:3030

构建时间: 2026/1/25 15:28:11
